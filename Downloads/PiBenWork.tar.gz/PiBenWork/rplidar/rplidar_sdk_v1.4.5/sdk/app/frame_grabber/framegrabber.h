// framegrabber.h
